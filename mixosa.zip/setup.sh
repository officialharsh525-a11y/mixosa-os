#!/usr/bin/env bash
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
  echo "❌ Error: Please run as root (sudo)."
  exit 1
fi

echo "🚀 Starting Full Mixosa OS Customization..."

# System Update
pacman -Syu --noconfirm
pacman -S --needed --noconfirm base-devel git curl wget unzip flatpak mesa

# VirtualBox Utilities
pacman -S --needed --noconfirm virtualbox-guest-utils xf86-video-vmware
systemctl enable vboxservice.service || true

# Performance Kernel & Tools
pacman -S --needed --noconfirm linux-zen linux-zen-headers

# Windows Compatibility Setup
pacman -S --needed --noconfirm wine-staging winetricks dxvk-bin samba
systemctl enable smb.service || true
systemctl enable nmb.service || true

# Flatpak & Bottles (Windows EXEs)
flatpak remote-add --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo
flatpak install -y flathub com.usebottles.bottles

# Apple Ecosystem (KDE Connect + LocalSend for AirDrop)
pacman -S --needed --noconfirm plasma-desktop kdeconnect
flatpak install -y flathub org.localsend.localsend_app

# Set up Yay (AUR Helper)
SUDO_USER_HOME=$(eval echo "~$SUDO_USER")
cd /tmp
if ! command -v yay &> /dev/null; then
    sudo -u "$SUDO_USER" git clone https://aur.archlinux.org/yay.git
    cd yay
    sudo -u "$SUDO_USER" makepkg -si --noconfirm
fi

# macOS Theme Auto-Installer
sudo -u "$SUDO_USER" bash -c '
    mkdir -p ~/.themes ~/.icons
    cd /tmp
    git clone https://github.com/vinceliuice/WhiteSur-gtk-theme.git --depth=1
    cd WhiteSur-gtk-theme
    ./install.sh -c dark -s 2k

    cd /tmp
    git clone https://github.com/vinceliuice/WhiteSur-icon-theme.git --depth=1
    cd WhiteSur-icon-theme
    ./install.sh
'

echo "✅ MIXOSA OS SETUP COMPLETED SUCCESSFULLY!"
